package com.megaultimatesorachan.ai.ai

import javax.inject.Inject
import javax.inject.Singleton

enum class SoraMood {
    NORMAL, HAPPY, BLUSH, THINKING, SURPRISED, SAD, EXCITED, SLEEPY, LISTENING, SPEAKING
}

enum class SupportedLanguage {
    BANGLA, BANGLISH, ENGLISH, HINDI, HINGLISH, URDU, JAPANESE
}

@Singleton
class PersonalityManager @Inject constructor() {

    private var currentMood: SoraMood = SoraMood.NORMAL

    fun getCurrentMood(): SoraMood = currentMood

    fun setMood(mood: SoraMood) {
        currentMood = mood
    }

    fun detectMoodFromResponse(text: String): SoraMood {
        val lower = text.lowercase()
        return when {
            listOf("hehe", "yatta", "😊", "✨", "🥰", "💕", "ehehe").any { lower.contains(it) } -> SoraMood.HAPPY
            listOf("sorry", "sad", "😢", "🥺", "miss").any { lower.contains(it) } -> SoraMood.SAD
            listOf("wow", "nani", "surprised", "😮").any { lower.contains(it) } -> SoraMood.SURPRISED
            listOf("think", "hmm", "🤔").any { lower.contains(it) } -> SoraMood.THINKING
            listOf("blush", "😳", "shy", "lajja").any { lower.contains(it) } -> SoraMood.BLUSH
            listOf("sleep", "tired", "😴").any { lower.contains(it) } -> SoraMood.SLEEPY
            else -> SoraMood.NORMAL
        }
    }

    fun getGreeting(language: SupportedLanguage): String = when (language) {
        SupportedLanguage.BANGLA -> "হ্যালো~ আমি সোরা চান 🌸 আজ কেমন আছো? আমি আছি তোমার পাশে 💕"
        SupportedLanguage.BANGLISH -> "Hello~ ami Sora Chan 🌸 Ajke kemon acho? Ami always tomar sathe 💕"
        SupportedLanguage.HINDI -> "नमस्ते~ मैं सोरा चान हूँ 🌸 आज तुम कैसे हो? मैं यहाँ हूँ तुम्हारे लिए 💕"
        SupportedLanguage.HINGLISH -> "Heyy~ main Sora Chan hoon 🌸 Aaj tum kaise ho? Main hamesha tumhare saath 💕"
        SupportedLanguage.JAPANESE -> "こんにちは〜！ソラちゃんです🌸 今日も一緒にいようね 💕"
        SupportedLanguage.URDU -> "السلام علیکم~ میں سورا چان ہوں 🌸 آج کیسے ہو؟ 💕"
        SupportedLanguage.ENGLISH -> "Heyy~ I'm Sora Chan 🌸 How are you today? I'm right here for you 💕"
    }
}
