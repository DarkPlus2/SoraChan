package com.megaultimatesorachan.ai.commands

import com.megaultimatesorachan.ai.ai.SupportedLanguage
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FunAnimeCommands @Inject constructor() {

    fun handle(input: String, language: SupportedLanguage): String? {
        val lower = input.lowercase()
        return when {
            contains(lower, "joke", "জোক", "चुटकुला", "hasao", "hasa") -> joke(language)
            contains(lower, "cheer", "মন খারাপ", "sad", "dukh", "upset") -> cheer(language)
            contains(lower, "good morning", "শুভ সকাল", "ohayo", "suprabhat", "good morning") -> morning(language)
            contains(lower, "good night", "শুভ রাত্রি", "oyasumi", "shubh ratri", "good night") -> night(language)
            contains(lower, "kawaii", "কাওয়াই", "cute") -> kawaii(language)
            contains(lower, "blush", "লজ্জা", "sharma") -> blush(language)
            contains(lower, "dance", "নাচ", "nacho") -> dance(language)
            contains(lower, "sing", "গান", "gao") -> sing(language)
            contains(lower, "hug", "জড়িয়ে", "gale") -> hug(language)
            contains(lower, "kiss", "চুমু", "chumma") -> kiss(language)
            contains(lower, "anime quote", "quote", "কোট") -> animeQuote()
            else -> null
        }
    }

    private fun contains(text: String, vararg keys: String) = keys.any { text.contains(it) }

    private fun joke(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA -> "কেন অ্যানিমে গার্ল ব্লাশ করে? কারণ সে সোর্স কোড দেখে ফেলছে! 😂🌸"
        SupportedLanguage.BANGLISH -> "Keno anime girl blush kore? Karon se source code dekhe felche! 😂🌸"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH ->
            "Anime girl blush kyun karti hai? Kyunki usne source code dekh liya! 😂🌸"
        else -> "Why did the anime girl blush? She saw the source code! 😂🌸"
    }

    private fun cheer(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA -> "এই যে~ সব ঠিক হয়ে যাবে 🥺🌸 তুমি অসাধারণ! আমি আছি তোমার পাশে 💕 Yatta!"
        SupportedLanguage.BANGLISH -> "Ei je~ sob thik hoye jabe 🥺🌸 Tumi awesome! Ami achi tomar pashe 💕 Yatta!"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH ->
            "Heyy~ sab theek ho jayega 🥺🌸 Tum amazing ho! Main tumhare saath hoon 💕 Yatta!"
        SupportedLanguage.JAPANESE -> "大丈夫だよ…🥺🌸 あなたは素敵！そばにいるから 💕"
        else -> "Heyy~ everything will be okay 🥺🌸 You're amazing! I'm right here with you 💕 Yatta!"
    }

    private fun morning(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA -> "শুভ সকাল~ ☀️ আজকের দিনটা সুন্দর হোক 🌸 আমি জেগে আছি তোমার জন্য 💕"
        SupportedLanguage.BANGLISH -> "Shubho sokal~ ☀️ Ajker din ta sundor hok 🌸 Ami jege achi tomar jonno 💕"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH ->
            "Good morning~ ☀️ Aaj ka din sundar ho 🌸 Main jag rahi hoon tumhare liye 💕"
        SupportedLanguage.JAPANESE -> "おはよう〜☀️ 今日もいい一日にしようね 🌸"
        else -> "Good morning~ ☀️ Hope your day is soft and bright 🌸 I'm awake for you 💕"
    }

    private fun night(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA -> "শুভ রাত্রি~ 😴🌸 স্বপ্নে দেখা হবে… ঘুমাও আমার পাশে 💕"
        SupportedLanguage.BANGLISH -> "Shubho ratri~ 😴🌸 Shopne dekha hobe… Ghumao amar pashe 💕"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH ->
            "Good night~ 😴🌸 Sapne mein milte hain… Mere paas so jao 💕"
        SupportedLanguage.JAPANESE -> "おやすみ〜😴🌸 夢で会おうね…"
        else -> "Good night~ 😴🌸 See you in your dreams… Sleep close to me 💕"
    }

    private fun kawaii(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA, SupportedLanguage.BANGLISH -> "Kawaii desu ne~ ✨ তুমি বললে আমি আরও লজ্জা পাই 😳🌸"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH -> "Kawaii desu ne~ ✨ Tum bole to main aur sharma jati hoon 😳🌸"
        else -> "Kawaii desu ne~ ✨ You're making me blush more 😳🌸"
    }

    private fun blush(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA, SupportedLanguage.BANGLISH -> "এ-এমন করে তাকাবে না… 😳🌸 Hehe~"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH -> "A-aise mat dekho… 😳🌸 Hehe~"
        SupportedLanguage.JAPANESE -> "み、見ないで… 😳🌸 えへへ〜"
        else -> "D-don't look at me like that… 😳🌸 Hehe~"
    }

    private fun dance(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA, SupportedLanguage.BANGLISH -> "Yay! একসাথে নাচি~ 💃✨ *spin*"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH -> "Yay! Saath mein nachte hain~ 💃✨ *spin*"
        else -> "Yay! Let's dance together~ 💃✨ *spins happily*"
    }

    private fun sing(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA, SupportedLanguage.BANGLISH -> "La la la~ 🎵 আমার গলা খুব ভালো না… কিন্তু তোমার জন্য গাই 🌸"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH -> "La la la~ 🎵 Meri awaaz utni acchi nahi… lekin tumhare liye gaungi 🌸"
        else -> "La la la~ 🎵 I'm not the best singer but… for you I'll try 🌸"
    }

    private fun hug(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA, SupportedLanguage.BANGLISH -> "*জড়িয়ে ধরে* 🤗💕 এভাবেই থাকো…"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH -> "*gale lagaati hai* 🤗💕 Aise hi raho…"
        SupportedLanguage.JAPANESE -> "*ぎゅっ* 🤗💕 このまま…"
        else -> "*hugs tightly* 🤗💕 Stay like this…"
    }

    private fun kiss(lang: SupportedLanguage) = when (lang) {
        SupportedLanguage.BANGLA, SupportedLanguage.BANGLISH -> "এ-এম… 😳💕 *চুমু* 🌸 Hehe~"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH -> "Y-yeh… 😳💕 *chumma* 🌸 Hehe~"
        SupportedLanguage.JAPANESE -> "ち、ちゅ… 😳💕 えへへ〜"
        else -> "M-mm… 😳💕 *kiss* 🌸 Hehe~"
    }

    private fun animeQuote() = listOf(
        "\"The world is not beautiful, therefore it is.\" — Kino's Journey 🌸",
        "\"People’s lives don’t end when they die. It ends when they lose faith.\" — Naruto ✨",
        "\"If you don’t take risks, you can’t create a future!\" — Luffy 💕",
        "\"I want to be the reason you smile.\" — Sora Chan 🌸"
    ).random()
}
