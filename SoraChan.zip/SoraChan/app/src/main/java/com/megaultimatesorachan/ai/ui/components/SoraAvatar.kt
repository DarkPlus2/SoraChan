package com.megaultimatesorachan.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.megaultimatesorachan.ai.ai.SoraMood
import com.megaultimatesorachan.ai.ui.theme.Accent
import com.megaultimatesorachan.ai.ui.theme.Primary
import com.megaultimatesorachan.ai.ui.theme.Secondary

@Composable
fun SoraAvatar(
    mood: SoraMood = SoraMood.NORMAL,
    size: Dp = 140.dp,
    isActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    val emoji = when (mood) {
        SoraMood.HAPPY -> "😊"
        SoraMood.BLUSH -> "😳"
        SoraMood.THINKING -> "🤔"
        SoraMood.SURPRISED -> "😮"
        SoraMood.SAD -> "😢"
        SoraMood.EXCITED -> "🤩"
        SoraMood.SLEEPY -> "😴"
        SoraMood.LISTENING -> "🎧"
        SoraMood.SPEAKING -> "🗣️"
        else -> "🌸"
    }

    val infinite = rememberInfiniteTransition(label = "avatarPulse")
    val scale by infinite.animateFloat(
        initialValue = 1f,
        targetValue = if (isActive) 1.06f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .size(size)
            .scale(scale)
            .shadow(12.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        Primary.copy(alpha = 0.95f),
                        Secondary.copy(alpha = 0.75f),
                        Accent.copy(alpha = 0.4f)
                    )
                )
            )
            .border(2.dp, Accent.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = emoji,
            fontSize = (size.value * 0.42f).sp,
            modifier = Modifier.padding(8.dp)
        )
    }
}
