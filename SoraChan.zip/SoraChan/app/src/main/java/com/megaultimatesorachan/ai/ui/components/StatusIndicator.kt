package com.megaultimatesorachan.ai.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.megaultimatesorachan.ai.ui.theme.Accent
import com.megaultimatesorachan.ai.ui.theme.Primary
import com.megaultimatesorachan.ai.ui.theme.Secondary
import com.megaultimatesorachan.ai.ui.theme.Success
import com.megaultimatesorachan.ai.ui.theme.Surface

enum class SoraStatus { IDLE, LISTENING, THINKING, SPEAKING }

@Composable
fun StatusIndicator(
    status: SoraStatus,
    modifier: Modifier = Modifier
) {
    val (text, targetColor) = when (status) {
        SoraStatus.IDLE -> "Ready" to Success
        SoraStatus.LISTENING -> "Listening…" to Secondary
        SoraStatus.THINKING -> "Thinking…" to Accent
        SoraStatus.SPEAKING -> "Speaking…" to Primary
    }
    val color by animateColorAsState(targetColor, tween(300), label = "statusColor")

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = modifier
            .background(Surface, RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Circle,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(9.dp)
        )
        Text(
            text = "  $text",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
