package com.megaultimatesorachan.ai.voice

import com.megaultimatesorachan.ai.ai.SupportedLanguage
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LanguageDetector @Inject constructor() {

    // Common Banglish / Hinglish cues
    private val banglishHints = listOf(
        "kemon", "acho", "ase", "kore", "hobe", "lagche", "bhalo", "tumi", "ami",
        "ki", "keno", "kothay", "ekhon", "pore", "valo", "bujho", "dosto", "bondhu",
        "khao", "jacchi", "asho", "thik", "ache", "naki", "na", "haan", "ji"
    )
    private val hinglishHints = listOf(
        "kya", "hai", "hoon", "tum", "mera", "tera", "kaise", "kyu", "kyun",
        "accha", "theek", "bahut", "nahi", "haan", "yaar", "bhai", "dil",
        "pyaar", "baat", "karo", "raha", "rahi", "gaya", "gayi"
    )

    fun detectLanguage(text: String): SupportedLanguage {
        val t = text.trim()
        if (t.isEmpty()) return SupportedLanguage.ENGLISH

        // Script-based (highest priority)
        when {
            t.any { it in '\u0980'..'\u09FF' } -> return SupportedLanguage.BANGLA      // বাংলা
            t.any { it in '\u0900'..'\u097F' } -> return SupportedLanguage.HINDI       // हिंदी
            t.any { it in '\u3040'..'\u30FF' || it in '\u4E00'..'\u9FFF' } ->
                return SupportedLanguage.JAPANESE
            t.any { it in '\u0600'..'\u06FF' } -> return SupportedLanguage.URDU
        }

        val lower = t.lowercase()
        val tokens = lower.split(Regex("\\s+"))

        val banglishScore = tokens.count { token -> banglishHints.any { token.contains(it) } }
        val hinglishScore = tokens.count { token -> hinglishHints.any { token.contains(it) } }

        return when {
            banglishScore >= 1 && banglishScore >= hinglishScore -> SupportedLanguage.BANGLISH
            hinglishScore >= 1 -> SupportedLanguage.HINGLISH
            else -> SupportedLanguage.ENGLISH
        }
    }

    fun toLocaleTag(lang: SupportedLanguage): String = when (lang) {
        SupportedLanguage.BANGLA, SupportedLanguage.BANGLISH -> "bn-BD"
        SupportedLanguage.HINDI, SupportedLanguage.HINGLISH -> "hi-IN"
        SupportedLanguage.ENGLISH -> "en-US"
        SupportedLanguage.URDU -> "ur-PK"
        SupportedLanguage.JAPANESE -> "ja-JP"
    }
}
